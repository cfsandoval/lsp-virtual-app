# LSP Virtual App (Replit Ready)
Operacionaliza talleres LEGO® SERIOUS PLAY® (LSP) online orientados a prospectiva: modelos, escenarios y backcasting.

## 1) Abrir en Replit
- Crea un nuevo Repl desde GitHub o sube el .zip.
- Asegúrate de que el entorno usa Node 20 (se define en `replit.nix`).

## 2) Variables de entorno (Secrets)
En Replit → Tools → Secrets:
```
NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
```
Opcional (solo si añadieras tareas admin server-side):
```
SUPABASE_SERVICE_ROLE_KEY=
```

## 3) Instalar y arrancar
```
npm install
npm run dev
```
Tu app quedará en `https://<tu-repl>.replit.dev` (puerto 3000).

## 4) Supabase
1. Crea un proyecto en https://supabase.com y copia URL/Anon Key.
2. Entra a **SQL** y ejecuta `db/supabase_schema.sql` (este repo).
3. En **Auth** crea (o invita) usuarios y perfila roles si lo deseas (este boilerplate no implementa auth UI, solo lectura/escritura abierta para demo).  
   > Para producción, agrega RLS y políticas, y un UI de login.

## 5) Estructura mínima
- `app/` (Next.js App Router)
- `lib/supabaseClient.ts` (cliente Supabase)
- `app/workshops/*` (lista/crear/ver taller)
- Tailwind ya configurado.

## 6) Próximos pasos
- Añadir Auth (Supabase Auth UI).
- Implementar CRUD completo: retos, modelos, escenarios, backcasting, acuerdos.
- Añadir export PDF/CSV y un tablero de métricas.
- Integrar prompts LLM para clustering, nombre de escenarios y chequeo de backcasting.

---
Licencia MIT.


## 7) Storage (imágenes de modelos)
En Supabase → **Storage** crea un bucket llamado **models** (público para prueba).
Luego podrás subir imágenes desde `/workshops/[id]/modelos`.
Para producción, configura RLS/Policies y firmas con URL temporal.

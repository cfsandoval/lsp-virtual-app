import Link from 'next/link'

export default function Home() {
  return (
    <main className="space-y-6">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold">LSP Virtual App</h1>
        <p className="text-gray-700">Operar talleres LSP virtuales orientados a prospectiva: modelos, escenarios y backcasting.</p>
      </header>

      <section className="grid gap-4 sm:grid-cols-2">
        <div className="card">
          <h2 className="text-xl font-semibold mb-2">Workshops</h2>
          <p className="mb-4">Crear y gestionar talleres (links de Zoom/Miro, estado, secuencia de retos).</p>
          <Link className="btn btn-primary" href="/workshops">Ir a Workshops</Link>
        </div>
        <div className="card">
          <h2 className="text-xl font-semibold mb-2">Guía rápida</h2>
          <ul className="list-disc pl-5 text-gray-700">
            <li>PREP → LIVE → CLOSE</li>
            <li>Retos: Warmup, Presente, Driver, Escenario, Fricción, Deseable, Backcasting</li>
            <li>Exportaciones: CSV/PDF (placeholder)</li>
          </ul>
        </div>
      </section>
    </main>
  )
}

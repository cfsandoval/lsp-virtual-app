'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'
import Protected from '@/components/Protected'
import Link from 'next/link'

type Workshop = {
  id: string
  title: string
  objective: string | null
  link_zoom: string | null
  link_miro: string | null
  state: 'PREP'|'LIVE'|'CLOSE'
}

type Reto = {
  id: string
  ord: number
  tipo: string
  pregunta: string
  instrucciones: string | null
  tiempo_min: number | null
  activo: boolean
}

const SEED_RETOS: Omit<Reto,'id'>[] = [
  { ord: 1, tipo: 'Warmup',    pregunta: 'Construye una torre/puente que represente tu día.', instrucciones: 'Familiarización y metáfora', tiempo_min: 7, activo: true },
  { ord: 2, tipo: 'Presente',  pregunta: 'Construye el presente de tu institución/territorio.', instrucciones: 'Diagnóstico compartido', tiempo_min: 7, activo: true },
  { ord: 3, tipo: 'Driver',    pregunta: 'Construye la fuerza de cambio más influyente.', instrucciones: 'Tendencias/señales', tiempo_min: 7, activo: true },
  { ord: 4, tipo: 'Escenario', pregunta: 'Construye el escenario plausible 2040.', instrucciones: 'Explorar futuros', tiempo_min: 10, activo: true },
  { ord: 5, tipo: 'Friccion',  pregunta: 'Construye fricciones/paradojas que bloquean o aceleran.', instrucciones: 'Riesgos y tensiones', tiempo_min: 7, activo: true },
  { ord: 6, tipo: 'Deseable',  pregunta: 'Construye tu futuro deseable 2040.', instrucciones: 'Visión y valores', tiempo_min: 7, activo: true },
  { ord: 7, tipo: 'Backcasting', pregunta: 'Construye el primer paso (T0) para acercarnos al futuro deseable.', instrucciones: 'Ruta de transición', tiempo_min: 5, activo: true },
]

export default function WorkshopDetail({ params }: { params: { id: string } }) {
  const id = params.id
  const r = useRouter()
  const [w, setW] = useState<Workshop | null>(null)
  const [retos, setRetos] = useState<Reto[]>([])
  const [loading, setLoading] = useState(true)

  async function load() {
    const { data: wdata } = await supabase.from('workshops').select('*').eq('id', id).single()
    setW(wdata as Workshop)
    const { data: rdata } = await supabase.from('retos').select('*').eq('workshop_id', id).order('ord')
    setRetos((rdata || []) as Reto[])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function seedRetos() {
    if (!w) return
    const payload = SEED_RETOS.map(r => ({
      workshop_id: w.id, ord: r.ord, tipo: r.tipo, pregunta: r.pregunta, instrucciones: r.instrucciones, tiempo_min: r.tiempo_min, activo: true
    }))
    await supabase.from('retos').insert(payload)
    await load()
  }

  async function setState(state: 'PREP'|'LIVE'|'CLOSE') {
    await supabase.from('workshops').update({ state }).eq('id', id)
    await load()
  }

  if (loading) return <p>Cargando…</p>

  return (
    <Protected>
      <main className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{w?.title}</h1>
            <p className="text-gray-700">{w?.objective}</p>
            <p className="text-sm">Estado: <span className="font-medium">{w?.state}</span></p>
          </div>
          <div className="flex gap-2">
            {w?.link_zoom && <a className="btn btn-ghost" href={w.link_zoom} target="_blank">Zoom</a>}
            {w?.link_miro && <a className="btn btn-ghost" href={w.link_miro} target="_blank">Miro</a>}
            <Link className="btn btn-primary" href={`/workshops/${id}/modelos`}>Modelos</Link>
          </div>
        </div>

        <div className="card">
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-ghost" onClick={() => setState('PREP')}>PREP</button>
            <button className="btn btn-ghost" onClick={() => setState('LIVE')}>LIVE</button>
            <button className="btn btn-ghost" onClick={() => setState('CLOSE')}>CLOSE</button>
            <button className="btn btn-primary" onClick={seedRetos}>Sembrar Retos estándar</button>
          </div>
        </div>

        <div className="card">
          <h2 className="text-xl font-semibold mb-2">Retos</h2>
          {retos.length === 0 && <p className="text-gray-600">Aún no hay retos. Usa “Sembrar Retos estándar”.</p>}
          <ul className="space-y-2">
            {retos.map(r => (
              <li key={r.id} className="border rounded-xl p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">#{r.ord} • {r.tipo}</p>
                    <p className="font-medium">{r.pregunta}</p>
                    {r.instrucciones && <p className="text-sm text-gray-700">{r.instrucciones}</p>}
                  </div>
                  <span className={`text-xs px-2 py-1 rounded ${r.activo ? 'bg-green-100 text-green-800':'bg-gray-100 text-gray-700'}`}>{r.activo ? 'Activo':'Inactivo'}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </main>
    </Protected>
  )
}

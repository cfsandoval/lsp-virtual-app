'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import Protected from '@/components/Protected'
import Link from 'next/link'

type Reto = { id: string, ord: number, tipo: string, pregunta: string }
type Modelo = {
  id: string
  foto_url: string
  relato_md: string
  etiquetas: string[] | null
  drivers: string[] | null
  created_at: string
}

export default function ModelosPage({ params }: { params: { id: string } }) {
  const workshop_id = params.id
  const [retos, setRetos] = useState<Reto[]>([])
  const [modelos, setModelos] = useState<Modelo[]>([])
  const [retoId, setRetoId] = useState<string>('')
  const [relato, setRelato] = useState('')
  const [etiquetas, setEtiquetas] = useState('')
  const [drivers, setDrivers] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [msg, setMsg] = useState<string>('')

  async function load() {
    const { data: rdata } = await supabase.from('retos').select('id, ord, tipo, pregunta').eq('workshop_id', workshop_id).order('ord')
    setRetos((rdata || []) as Reto[])
    const { data: mdata } = await supabase.from('modelos').select('*').eq('workshop_id', workshop_id).order('created_at', { ascending: false })
    setModelos((mdata || []) as Modelo[])
  }
  useEffect(() => { load() }, [])

  async function upload() {
    setMsg('')
    if (!file) { setMsg('Sube una imagen.'); return }
    if (!relato || relato.length < 240) { setMsg('El relato debe tener al menos 240 caracteres.'); return }
    const fname = `${workshop_id}/${Date.now()}_${file.name}`
    const { data: up, error: upErr } = await supabase.storage.from('models').upload(fname, file, { upsert: false })
    if (upErr) { setMsg(upErr.message); return }
    const { data: url } = supabase.storage.from('models').getPublicUrl(fname)
    const { error: insErr } = await supabase.from('modelos').insert({
      workshop_id, reto_id: retoId || null, foto_url: url.publicUrl,
      relato_md: relato, etiquetas: etiquetas ? etiquetas.split(',').map(s => s.trim()) : null,
      drivers: drivers ? drivers.split(',').map(s => s.trim()) : null
    })
    if (insErr) { setMsg(insErr.message); return }
    setMsg('Modelo subido.')
    setFile(null); setRelato(''); setEtiquetas(''); setDrivers(''); setRetoId('')
    await load()
  }

  return (
    <Protected>
      <main className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Modelos</h1>
          <Link className="btn btn-ghost" href={`/workshops/${workshop_id}`}>Volver</Link>
        </div>

        <div className="card space-y-3">
          <h2 className="text-lg font-semibold">Subir modelo</h2>
          <label className="label">Reto</label>
          <select className="input" value={retoId} onChange={e=>setRetoId(e.target.value)}>
            <option value="">(opcional)</option>
            {retos.map(r => <option key={r.id} value={r.id}>{r.ord}. {r.tipo} — {r.pregunta}</option>)}
          </select>

          <label className="label">Imagen</label>
          <input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0] || null)} />

          <label className="label">Relato (≥ 240 caracteres)</label>
          <textarea className="input" rows={6} value={relato} onChange={e=>setRelato(e.target.value)} />

          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="label">Etiquetas (coma-separadas)</label>
              <input className="input" value={etiquetas} onChange={e=>setEtiquetas(e.target.value)} />
            </div>
            <div>
              <label className="label">Drivers (coma-separadas)</label>
              <input className="input" value={drivers} onChange={e=>setDrivers(e.target.value)} />
            </div>
          </div>

          <button className="btn btn-primary" onClick={upload}>Guardar modelo</button>
          {msg && <p className="text-sm">{msg}</p>}
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-2">Galería</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {modelos.map(m => (
              <figure key={m.id} className="border rounded-xl p-3">
                <img src={m.foto_url} alt="modelo" className="w-full h-48 object-cover rounded-lg" />
                <figcaption className="mt-2 text-sm text-gray-700 line-clamp-4">{m.relato_md}</figcaption>
                {m.etiquetas && <p className="text-xs mt-1">Etiquetas: {m.etiquetas.join(', ')}</p>}
                {m.drivers && <p className="text-xs">Drivers: {m.drivers.join(', ')}</p>}
              </figure>
            ))}
          </div>
        </div>
      </main>
    </Protected>
  )
}

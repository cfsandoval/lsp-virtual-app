'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'

export default function NewWorkshopPage() {
  const r = useRouter()
  const [title, setTitle] = useState('Taller LSP – Prospectiva')
  const [objective, setObjective] = useState('Escenarios 2040 y ruta de acción (backcasting)')
  const [link_zoom, setZoom] = useState('')
  const [link_miro, setMiro] = useState('')

  async function create() {
    const { data, error } = await supabase.from('workshops').insert({
      title, objective, link_zoom, link_miro, state: 'PREP'
    }).select('id').single()
    if (!error && data) r.push(`/workshops/${data.id}`)
    else alert(error?.message || 'Error creando workshop')
  }

  return (
    <main className="space-y-4 max-w-2xl">
      <h1 className="text-2xl font-bold">Nuevo Workshop</h1>
      <label className="label">Título</label>
      <input className="input" value={title} onChange={e=>setTitle(e.target.value)} />
      <label className="label">Objetivo</label>
      <textarea className="input" rows={3} value={objective} onChange={e=>setObjective(e.target.value)} />
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className="label">Link Zoom</label>
          <input className="input" value={link_zoom} onChange={e=>setZoom(e.target.value)} />
        </div>
        <div>
          <label className="label">Link Miro</label>
          <input className="input" value={link_miro} onChange={e=>setMiro(e.target.value)} />
        </div>
      </div>
      <button className="btn btn-primary" onClick={create}>Crear</button>
    </main>
  )
}

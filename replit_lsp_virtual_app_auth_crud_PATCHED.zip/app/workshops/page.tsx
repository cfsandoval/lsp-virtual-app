'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { supabase } from '@/lib/supabaseClient'

type Workshop = {
  id: string
  title: string
  objective: string | null
  date: string | null
  duration_min: number | null
  link_zoom: string | null
  link_miro: string | null
  state: 'PREP'|'LIVE'|'CLOSE'
}

export default function WorkshopsPage() {
  const [rows, setRows] = useState<Workshop[]>([])

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.from('workshops').select('*').order('created_at', { ascending: false })
      if (!error && data) setRows(data as Workshop[])
    })()
  }, [])

  return (
    <main className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Workshops</h1>
        <Link className="btn btn-primary" href="/workshops/new">Nuevo Workshop</Link>
      </div>

      <div className="grid gap-3">
        {rows.map((w) => (
          <div key={w.id} className="card">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold">{w.title}</h2>
                <p className="text-sm text-gray-600">{w.objective}</p>
                <p className="text-sm">Estado: <span className="font-medium">{w.state}</span></p>
              </div>
              <div className="flex gap-2">
                {w.link_zoom && <a className="btn btn-ghost" href={w.link_zoom} target="_blank">Zoom</a>}
                {w.link_miro && <a className="btn btn-ghost" href={w.link_miro} target="_blank">Miro</a>}
                <Link className="btn btn-primary" href={`/workshops/${w.id}`}>Abrir</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  )
}

'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabaseClient'

export default function AuthPage() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function sendMagicLink() {
    setError(null)
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: typeof window !== 'undefined' ? window.location.origin : undefined } })
    if (error) setError(error.message)
    else setSent(true)
  }

  return (
    <main className="max-w-md space-y-4">
      <h1 className="text-2xl font-bold">Iniciar sesión</h1>
      <p className="text-gray-700">Accede con tu correo. Te enviaremos un enlace mágico.</p>
      <input className="input" placeholder="tu@correo.com" value={email} onChange={e=>setEmail(e.target.value)} />
      <button className="btn btn-primary" onClick={sendMagicLink}>Enviar enlace</button>
      {sent && <p className="text-green-700">¡Revisa tu correo y abre el enlace para iniciar sesión!</p>}
      {error && <p className="text-red-700">{error}</p>}
    </main>
  )
}

import './globals.css'
import type { Metadata } from 'next'
import { AuthProvider } from '@/lib/authClient'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'LSP Virtual App',
  description: 'Operacionaliza talleres LEGO® SERIOUS PLAY® online con escenarios y backcasting.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>
        <nav className="border-b">
          <div className="container py-3 flex items-center gap-4">
            <Link href="/" className="font-semibold">LSP Virtual App</Link>
            <div className="ml-auto flex gap-3">
              <Link href="/auth" className="btn btn-ghost">Iniciar sesión</Link>
              <Link href="/workshops" className="btn btn-ghost">Workshops</Link>
            </div>
          </div>
        </nav>
        <div className="container py-6">
          <AuthProvider>{children}</AuthProvider>
        </div>
      </body>
    </html>
  )
}

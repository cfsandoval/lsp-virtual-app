'use client'
import { useAuth } from '@/lib/authClient'
import Link from 'next/link'

export default function Protected({ children }: { children: React.ReactNode }) {
  const { session, loading } = useAuth()
  if (loading) return <p>Cargando…</p>
  if (!session) {
    return (
      <div className="card">
        <h2 className="text-xl font-semibold mb-2">Acceso restringido</h2>
        <p className="mb-4">Inicia sesión para continuar.</p>
        <Link className="btn btn-primary" href="/auth">Ir a iniciar sesión</Link>
      </div>
    )
  }
  return <>{children}</>
}

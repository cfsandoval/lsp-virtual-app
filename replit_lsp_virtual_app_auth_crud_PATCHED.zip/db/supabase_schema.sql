-- Run this in Supabase SQL editor

create extension if not exists "uuid-ossp";

create table if not exists profiles (
  id uuid primary key,
  full_name text,
  role text check (role in ('facilitator','cofacilitator','participant')),
  org text, country text, created_at timestamptz default now()
);

create table if not exists workshops (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  objective text,
  date timestamptz,
  duration_min int,
  link_zoom text, link_miro text,
  state text check (state in ('PREP','LIVE','CLOSE')) default 'PREP',
  consent_md text,
  owner uuid references profiles(id),
  created_at timestamptz default now()
);

create table if not exists retos (
  id uuid primary key default gen_random_uuid(),
  workshop_id uuid references workshops(id) on delete cascade,
  ord smallint,
  tipo text check (tipo in ('Warmup','Presente','Driver','Escenario','Friccion','Deseable','Backcasting')),
  pregunta text, instrucciones text, tiempo_min smallint,
  activo boolean default true
);

create table if not exists modelos (
  id uuid primary key default gen_random_uuid(),
  reto_id uuid references retos(id) on delete set null,
  workshop_id uuid references workshops(id) on delete cascade,
  author uuid,
  foto_url text not null,
  relato_md text not null,
  etiquetas text[],
  drivers text[],
  created_at timestamptz default now()
);

create table if not exists escenarios (
  id uuid primary key default gen_random_uuid(),
  workshop_id uuid references workshops(id) on delete cascade,
  nombre text, descripcion_md text,
  criterios_md text,
  conexiones jsonb default '[]',
  imagen_compuesta_url text,
  created_at timestamptz default now()
);

create table if not exists escenario_modelo (
  escenario_id uuid references escenarios(id) on delete cascade,
  modelo_id uuid references modelos(id) on delete cascade,
  primary key (escenario_id, modelo_id)
);

create table if not exists backcasting_hitos (
  id uuid primary key default gen_random_uuid(),
  workshop_id uuid references workshops(id) on delete cascade,
  horizonte text check (horizonte in ('T0','T+90','T+180','T+365')),
  hito_md text, responsable text, kpi text, dependencia text, riesgo_md text
);

create table if not exists acuerdos (
  id uuid primary key default gen_random_uuid(),
  workshop_id uuid references workshops(id) on delete cascade,
  acuerdo_md text, responsable text, fecha date, evidencia_url text,
  estado text check (estado in ('Abierto','En curso','Completado')) default 'Abierto'
);

create table if not exists encuestas (
  id uuid primary key default gen_random_uuid(),
  workshop_id uuid references workshops(id) on delete cascade,
  profile_id uuid,
  momento text check (momento in ('pre','post')),
  respuestas jsonb, nps smallint,
  created_at timestamptz default now(),
  unique (workshop_id, profile_id, momento)
);

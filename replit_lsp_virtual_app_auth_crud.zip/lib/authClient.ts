'use client'
import { supabase } from './supabaseClient'
import { useEffect, useState, createContext, useContext } from 'react'

type Session = import('@supabase/supabase-js').Session | null

const AuthCtx = createContext<{session: Session, loading: boolean}>({
  session: null, loading: true
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session ?? null)
      setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, sess) => {
      setSession(sess)
      setLoading(false)
    })
    return () => { sub.subscription.unsubscribe() }
  }, [])

  return <AuthCtx.Provider value={{ session, loading }}>{children}</AuthCtx.Provider>
}

export function useAuth() {
  return useContext(AuthCtx)
}
